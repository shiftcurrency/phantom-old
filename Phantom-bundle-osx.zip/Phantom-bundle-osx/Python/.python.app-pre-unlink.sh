#!/bin/bash
rm -rf $PREFIX/python.app
