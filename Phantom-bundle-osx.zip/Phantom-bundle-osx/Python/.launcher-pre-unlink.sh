#!/bin/bash
rm -rf $PREFIX/Launcher.app
rm -f $HOME/Desktop/Launcher.app
