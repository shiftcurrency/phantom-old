find .. -name '*.pyc' -delete
find .. -name '*.pyo' -delete
find .. -name '*.DS_Store' -delete