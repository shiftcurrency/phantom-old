# This file exists as a helper for the test.test_frozen module.
